var _a_d_c_8h =
[
    [ "ADC", "class_a_d_c.html", "class_a_d_c" ],
    [ "Sync_result", "struct_a_d_c_1_1_sync__result.html", "struct_a_d_c_1_1_sync__result" ],
    [ "ADC_0", "_a_d_c_8h.html#a5cbcaa568e20fcd4cc9325927d370860", null ],
    [ "ADC_1", "_a_d_c_8h.html#a3d767e16f12a6ee542079f3c9677192c", null ]
];