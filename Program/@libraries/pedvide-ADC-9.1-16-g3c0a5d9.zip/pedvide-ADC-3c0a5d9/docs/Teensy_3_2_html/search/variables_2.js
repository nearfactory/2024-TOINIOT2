var searchData=
[
  ['diff_5ftable_5fadc0_237',['diff_table_ADC0',['../class_a_d_c.html#a3ac941166af84754393ce2e3006a1c16',1,'ADC']]],
  ['diff_5ftable_5fadc1_238',['diff_table_ADC1',['../class_a_d_c.html#ac75d6d8768a6def95664d8bb00ae502a',1,'ADC']]]
];
