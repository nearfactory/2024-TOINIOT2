var searchData=
[
  ['calib_35',['CALIB',['../namespace_a_d_c___error.html#ad050c44d1f3422d02e5f9726edeee8f0ae1f7d44eff22f533115c24a249c57269',1,'ADC_Error']]],
  ['calibrate_36',['calibrate',['../class_a_d_c___module.html#a037ab0589e2966cd07292c8186cad83e',1,'ADC_Module']]],
  ['channel2sc1aadc0_37',['channel2sc1aADC0',['../class_a_d_c.html#ab790c1b44b90ff497cbf3e88f4580be8',1,'ADC']]],
  ['channel2sc1aadc1_38',['channel2sc1aADC1',['../class_a_d_c.html#a756fe8fa6da7ab09cde1f7b27aeffd43',1,'ADC']]],
  ['checkdifferentialpins_39',['checkDifferentialPins',['../class_a_d_c___module.html#a80d29662a1a32a51fec606351685ebaf',1,'ADC_Module']]],
  ['checkpin_40',['checkPin',['../class_a_d_c___module.html#a9fd95a61d263a9d82918b50e81aee2e9',1,'ADC_Module']]],
  ['clear_41',['CLEAR',['../namespace_a_d_c___error.html#ad050c44d1f3422d02e5f9726edeee8f0a813461e0c58e7ad59a2fd83ca2237fec',1,'ADC_Error']]],
  ['comparison_42',['COMPARISON',['../namespace_a_d_c___error.html#ad050c44d1f3422d02e5f9726edeee8f0a4fd4da223d344be375847dcacc013d7f',1,'ADC_Error']]],
  ['cont_43',['CONT',['../namespace_a_d_c___error.html#ad050c44d1f3422d02e5f9726edeee8f0a53f6b3ace3aa40916de167636293ac80',1,'ADC_Error']]],
  ['cont_5fdiff_44',['CONT_DIFF',['../namespace_a_d_c___error.html#ad050c44d1f3422d02e5f9726edeee8f0ac16bcb11fac967e648e4d534e2c84683',1,'ADC_Error']]],
  ['continuousmode_45',['continuousMode',['../class_a_d_c___module.html#a8b00e0669bbc7917544d4e2e543f1a27',1,'ADC_Module']]],
  ['conversion_5fspeed_5flist_46',['conversion_speed_list',['../namespace_a_d_c__util.html#afb6703ab0983fe02a0c5de9d771c0757',1,'ADC_util']]]
];
