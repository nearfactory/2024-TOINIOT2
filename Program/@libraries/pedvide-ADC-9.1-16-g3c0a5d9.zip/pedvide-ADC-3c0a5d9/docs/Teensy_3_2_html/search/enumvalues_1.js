var searchData=
[
  ['bandgap_263',['BANDGAP',['../namespace_a_d_c__settings.html#a8c2a64f3fca3ac6b82e8df8cf44f6ca2aec822af60bc7412ff73aecb3edffa55c',1,'ADC_settings']]]
];
