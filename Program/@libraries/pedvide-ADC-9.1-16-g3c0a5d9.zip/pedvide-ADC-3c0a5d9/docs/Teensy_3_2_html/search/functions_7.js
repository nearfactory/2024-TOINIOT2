var searchData=
[
  ['readsingle_191',['readSingle',['../class_a_d_c.html#aee7423bfcbb03465bb0bd1e3c6474452',1,'ADC::readSingle()'],['../class_a_d_c___module.html#a60d0edc82fd1dbb2e20d090a53718ce2',1,'ADC_Module::readSingle()']]],
  ['readsynchronizedcontinuous_192',['readSynchronizedContinuous',['../class_a_d_c.html#acd10f3bc117a244e70e53c3489aa97bc',1,'ADC']]],
  ['readsynchronizedsingle_193',['readSynchronizedSingle',['../class_a_d_c.html#a38d941542bbdbc20c1b9e26a5051094a',1,'ADC']]],
  ['recalibrate_194',['recalibrate',['../class_a_d_c___module.html#afe8ed6f2a6c811ec3ef2c4aba768982f',1,'ADC_Module']]],
  ['reseterror_195',['resetError',['../class_a_d_c.html#aa65014de31051e06a469982ca286496b',1,'ADC::resetError()'],['../class_a_d_c___module.html#abf980784cf468d28fc2cbb94d06be500',1,'ADC_Module::resetError()']]]
];
