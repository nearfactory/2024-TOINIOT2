var searchData=
[
  ['channel2sc1aadc0_234',['channel2sc1aADC0',['../class_a_d_c.html#ab790c1b44b90ff497cbf3e88f4580be8',1,'ADC']]],
  ['channel2sc1aadc1_235',['channel2sc1aADC1',['../class_a_d_c.html#a756fe8fa6da7ab09cde1f7b27aeffd43',1,'ADC']]],
  ['conversion_5fspeed_5flist_236',['conversion_speed_list',['../namespace_a_d_c__util.html#afb6703ab0983fe02a0c5de9d771c0757',1,'ADC_util']]]
];
