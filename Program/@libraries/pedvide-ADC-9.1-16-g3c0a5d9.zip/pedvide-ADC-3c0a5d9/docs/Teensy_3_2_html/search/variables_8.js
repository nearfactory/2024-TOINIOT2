var searchData=
[
  ['sampling_5fspeed_5flist_333',['sampling_speed_list',['../namespace_a_d_c__util.html#ad813ee6b28ef93d8bc7d0c3bf62b967b',1,'ADC_util']]],
  ['savedcfg1_334',['savedCFG1',['../struct_a_d_c___module_1_1_a_d_c___config.html#a54092156c81d6dc11b521faf791751f6',1,'ADC_Module::ADC_Config']]],
  ['savedcfg2_335',['savedCFG2',['../struct_a_d_c___module_1_1_a_d_c___config.html#ab1fc8559f2f2f9b9fc0c77a9e67ff2a6',1,'ADC_Module::ADC_Config']]],
  ['savedsc1a_336',['savedSC1A',['../struct_a_d_c___module_1_1_a_d_c___config.html#a708e83c3bbd11a06d88802b8941e19a8',1,'ADC_Module::ADC_Config']]],
  ['savedsc2_337',['savedSC2',['../struct_a_d_c___module_1_1_a_d_c___config.html#a9f2fc51728d47cd8f6e8b00e8f400296',1,'ADC_Module::ADC_Config']]],
  ['savedsc3_338',['savedSC3',['../struct_a_d_c___module_1_1_a_d_c___config.html#ae04df65edae35a9beaaec59ce39b1e9e',1,'ADC_Module::ADC_Config']]],
  ['sc1a_339',['sc1a',['../struct_a_d_c___module_1_1_a_d_c___n_l_i_s_t.html#a3169dfd9150d30c4c5cc8459659099aa',1,'ADC_Module::ADC_NLIST']]],
  ['sc1a2channeladc0_340',['sc1a2channelADC0',['../class_a_d_c.html#a4377c680975fe754de24b8f8617042de',1,'ADC']]],
  ['sc1a2channeladc1_341',['sc1a2channelADC1',['../class_a_d_c.html#a34e8ad9674e566e5ad7e0187e4393fcd',1,'ADC']]]
];
