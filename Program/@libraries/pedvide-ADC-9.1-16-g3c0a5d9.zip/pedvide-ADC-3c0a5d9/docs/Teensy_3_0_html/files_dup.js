var files_dup =
[
    [ "ADC.cpp", "_a_d_c_8cpp_source.html", null ],
    [ "ADC.h", "_a_d_c_8h_source.html", null ],
    [ "ADC_Module.cpp", "_a_d_c___module_8cpp_source.html", null ],
    [ "ADC_Module.h", "_a_d_c___module_8h_source.html", null ],
    [ "ADC_util.h", "_a_d_c__util_8h_source.html", null ],
    [ "AnalogBufferDMA.cpp", "_analog_buffer_d_m_a_8cpp_source.html", null ],
    [ "AnalogBufferDMA.h", "_analog_buffer_d_m_a_8h_source.html", null ],
    [ "atomic.h", "atomic_8h_source.html", null ],
    [ "settings_defines.h", "settings__defines_8h_source.html", null ],
    [ "VREF.h", "_v_r_e_f_8h_source.html", null ]
];