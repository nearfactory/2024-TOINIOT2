var struct_a_d_c___module_1_1_a_d_c___config =
[
    [ "savedCFG1", "struct_a_d_c___module_1_1_a_d_c___config.html#a54092156c81d6dc11b521faf791751f6", null ],
    [ "savedCFG2", "struct_a_d_c___module_1_1_a_d_c___config.html#ab1fc8559f2f2f9b9fc0c77a9e67ff2a6", null ],
    [ "savedSC1A", "struct_a_d_c___module_1_1_a_d_c___config.html#a708e83c3bbd11a06d88802b8941e19a8", null ],
    [ "savedSC2", "struct_a_d_c___module_1_1_a_d_c___config.html#a9f2fc51728d47cd8f6e8b00e8f400296", null ],
    [ "savedSC3", "struct_a_d_c___module_1_1_a_d_c___config.html#ae04df65edae35a9beaaec59ce39b1e9e", null ]
];