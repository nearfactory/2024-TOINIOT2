var _a_d_c___module_8h =
[
    [ "ADC_Module", "class_a_d_c___module.html", "class_a_d_c___module" ],
    [ "ADC_Config", "struct_a_d_c___module_1_1_a_d_c___config.html", "struct_a_d_c___module_1_1_a_d_c___config" ],
    [ "ADC_debug", "_a_d_c___module_8h.html#aaaf2912bdda454e3fcb88156f1ce20d8", null ]
];