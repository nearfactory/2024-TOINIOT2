var searchData=
[
  ['settings_5fdefines_2eh_213',['settings_defines.h',['../settings__defines_8h.html',1,'']]]
];
