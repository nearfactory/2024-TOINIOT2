var searchData=
[
  ['userdata_272',['userData',['../class_analog_buffer_d_m_a.html#a954fe8ae896c3570b13d76b5e122bf85',1,'AnalogBufferDMA::userData(uint32_t new_data)'],['../class_analog_buffer_d_m_a.html#ad46e5a0de97999d41407b0ad02b975c2',1,'AnalogBufferDMA::userData(void)']]]
];
