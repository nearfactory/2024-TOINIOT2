var searchData=
[
  ['low_5fspeed_227',['LOW_SPEED',['../namespace_a_d_c__settings.html#aab853fc1fcb1992fd5d51408adf7688eaaa486942a3788373f56f1955a6c97c9b',1,'ADC_settings::LOW_SPEED()'],['../namespace_a_d_c__settings.html#af0d80a1aae7288f77b13f0e01d9da0d3aaa486942a3788373f56f1955a6c97c9b',1,'ADC_settings::LOW_SPEED()']]]
];
