var searchData=
[
  ['enablecompare_46',['enableCompare',['../class_a_d_c.html#ad0737a1d21656cccc47851b85f4b3fc7',1,'ADC::enableCompare()'],['../class_a_d_c___module.html#ae7a632267f21b79c31c1dae56b5da188',1,'ADC_Module::enableCompare()']]],
  ['enablecomparerange_47',['enableCompareRange',['../class_a_d_c.html#aa2b5a656add303432afcd298f1a52110',1,'ADC::enableCompareRange()'],['../class_a_d_c___module.html#ab8e64bab9d4e7f1935a260629e5d71d5',1,'ADC_Module::enableCompareRange()']]],
  ['enabledma_48',['enableDMA',['../class_a_d_c.html#a10b9e674ed487b81160687e38fafbb59',1,'ADC::enableDMA()'],['../class_a_d_c___module.html#af3d14c01b1442c0c34b5dbc9a6e49f35',1,'ADC_Module::enableDMA()']]],
  ['enableinterrupts_49',['enableInterrupts',['../class_a_d_c.html#af81b3c7805c688558ab25d66a8adf982',1,'ADC::enableInterrupts()'],['../class_a_d_c___module.html#a65395dfc2a15bc015e1ee723b22235b5',1,'ADC_Module::enableInterrupts()']]]
];
